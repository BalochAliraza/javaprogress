/**
 * 
 */
/**
 * @author sufyan_ahmed_rajput
 *
 */
module myproject {
	requires java.desktop;
}